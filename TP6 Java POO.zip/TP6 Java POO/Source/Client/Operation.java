/**
 * La classe abstraite Operation est une super classe qui effectue des traitement selon un message
 *
 * @author Kévin Démaret
 * @version 1.0
 */
public abstract class Operation {
	
	// Attributs d'instances
	
	private Message message;
	
	// Méthodes de classe
	
	/**
	 * Constructeur
	 * @param message Message sur lequel l'opération doit porter
	 */
	public Operation(Message message) {
		this.message = message;
	}
	
	// Méthodes d'instances
	
	/**
	 * Renvoi le message
	 */
	public Message getMessage() {
		return this.message;
	}
	
	/**
	 * Traite le message, à implémenter dans les classes filles
	 */
	public abstract void traiter();
	
}
