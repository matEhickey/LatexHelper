/**
 * L'interface Observateur permet de définir des classes comme observatrices de classes observables
 *
 * @author Kévin Démaret
 * @version 1.0
 */
public interface Observateur {
	
	public void miseAJour(Observable obs);
	
}
