// Imports
import java.io.*;
import java.net.*;

/**
 * La classe ConnexionServeur gère toutes les entrées/sorties avec le serveur
 *
 * @author Kévin Démaret
 * @version 1.0
 */
public class ConnexionServeur implements Runnable {
	
	// Attributs d'instance
	
	private Socket socket;
	private ObjectOutputStream out;
	private ObjectInputStream in;
	private Thread thread;
	private Controleur controleur;
	
	// Méthodes de classe
	
	/**
	 * Constructeur
	 * @param c Contrôleur liée
	 */
	public ConnexionServeur(Controleur c) {
		this.socket = null;
		this.out = null;
		this.in = null;
		this.thread = null;
		this.controleur = c;
	}
	
	// Méthodes d'instance
	
	/**
	 * Se connecte à un serveur et lance un thread pour l'écoute de données entrantes
	 * @param ip Adresse IP du serveur
	 * @param port Port du serveur
	 * @return Renvoi true si la connexion a pu être établie, false si non
	 */
	public boolean connexion(String ip, int port) {
		try {
			// Connexion
			this.socket = new Socket(ip, port);
			
			// Liaison des entrées/sorties
			this.out = new ObjectOutputStream(this.socket.getOutputStream());
			this.out.flush();
			this.in = new ObjectInputStream(this.socket.getInputStream());
			
			// Lancement du thread
			this.thread = new Thread(this);
			this.thread.start();
		}
		catch(Exception e) {
			// e.printStackTrace();
			this.initialisation();
			return false;
		}
		
		return true;
	}
	
	/**
	 * Interrompt le thread d'écoute, ferme le socket puis met toutes les références à null
	 */
	private void initialisation() {
		// Arrêt du tread
		if(this.thread != null)
			this.thread.interrupt();
		
		// Fermeture du socket
		try {
			if(this.socket != null)
				this.socket.close();
		}
		catch(Exception e) {
			// e.printStackTrace();
		}
		
		// Mise à null des références
		this.socket = null;
		this.out = null;
		this.in = null;
	}
	
	/**
	 * Se déconnecte du serveur et interrompt le thread d'écoute
	 */
	public void deconnexion() {
		this.initialisation();
	}
	
	/**
	 * Envoi de données au serveur
	 * @param msg Message à transmettre au serveur
	 */
	public void envoyerMessage(Message msg) {
		try {
			this.out.writeObject(msg);
			this.out.flush();
		}
		catch(Exception e) {
			// e.printStackTrace();
			this.initialisation();
			this.controleur.setConnexion(false);
			this.controleur.addDiscussion("La connexion avec le serveur a été rompu !");
		}
	}
	
	/**
	 * Ecoute de données entrantes
	 * @note La méthode readObject() étant bloquante, elle ne détecte pas imédiatement la deconnexion
	 */
	public void run() {
		Message msg = null;
		try {
			while(true) {
				msg = (Message) this.in.readObject(); // On dé-sérialise le message
				// System.out.println("Réception de " + msg.getOperation() + " " + msg.getArguments().size() + " argument(s)");
				
				msg.ajouterArgument(this.controleur); // On ajoute une référence du contrôleur pour le traitement
				Message.traiter(msg); // Traitement du message
			}
		}
		catch(Exception e) {
			// e.printStackTrace();
			this.initialisation();
			this.controleur.setConnexion(false);
			this.controleur.addDiscussion("La connexion avec le serveur a été rompu !");
		}
	}
}
