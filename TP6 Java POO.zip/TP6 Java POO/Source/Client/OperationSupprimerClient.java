// Imports
import java.util.ArrayList;

/**
 * Opération réalisé pour supprimer un utilisateur à la liste des connectés
 */
public class OperationSupprimerClient extends Operation {
	
	// Méthodes de classe
	
	/**
	 * Constructeur
	 * @param message Message sur lequel l'opération doit porter
	 */
	public OperationSupprimerClient(Message message) {
		super(message);
	}
	
	// Méthodes d'instances
	
	/**
	 * Supprime les pseudo de la liste des connectées
	 */
	public void traiter() {
		// Lecture des arguments
		ArrayList arguments = this.getMessage().getArguments();
		String nom = (String) arguments.get(0);
		Controleur c = (Controleur) arguments.get(1);
		
		// Envoi du nom au controleur
		c.removeConnectes(nom);
		
		// Discussion
		c.addDiscussion( nom + " s'est dé-connecté(e)." );
	}
}
