/**
 * La classe Contrôleur orchestre le modèle et la vue
 *
 * @author Kévin Démaret
 * @version 1.0
 */
public class Controleur {
	
	// Attributs d'instance
	
	private Modele modele;
	private ConnexionServeur cs;
	
	// Méthodes de classe
	
	public Controleur(Modele m) {
		this.modele = m;
		this.cs = new ConnexionServeur(this);
	}
	
	// Méthodes d'instances
	
	/**
	 * Gestion de la connexion avec le serveur (en provenance de l'utilisateur par l'intermédiare de Vue)
	 */
	public void gestionConnexion(String nom, String ip, int port) {
		
		// Si la connexion n'est pas encore établie
		if( !this.modele.getConnexion() ) {
			
			// Si la connexion au serveur est un succès
			if( this.cs.connexion(ip, port) ) {
				
				// Maj du modèle (et de la vue)
				this.setConnexion(true);
				this.addDiscussion("Vous êtes connecté !");
				
				// Envoi message bonjour
				Message msg = new Message("OperationBonjour");
				msg.ajouterArgument(nom);
				this.cs.envoyerMessage(msg);
			}
			// Sinon la connexion au serveur est un échec
			else {
				// Maj du modèle (et de la vue)
				this.setConnexion(false);
				this.addDiscussion("Impossible de se connecter !");
			}
			
		}
		// Sinon la connexion est déjà établie
		else {
			
			// Déconnexion
			this.cs.deconnexion();
			
			// Maj modèle
			this.setConnexion(false);
			this.addDiscussion("Vous avez bien été déconnecté !");
		}
	}
	
	/**
	 * Envoi un message au serveur (en provenance de l'utilisateur par l'intermédiare de Vue)
	 * @param str Message à envoyer
	 */
	public void envoyerMessage(String str) {
		if( !str.equals("") ) {
			Message msg = new Message("OperationMessageClient");
			msg.ajouterArgument(str);
			this.cs.envoyerMessage(msg);
		}
	}
	
	/**
	 * Ajoute un nom à la liste des connectés (en provenance du serveur par l'intermédiare de ConnexionServeur)
	 * @param nom Nom à ajouter
	 */
	public void addConnectes(String nom) {
		this.modele.addConnectes(nom);
	}
	
	/**
	 * Supprime un nom de la liste des connectés (en provenance du serveur par l'intermédiare de ConnexionServeur)
	 * @param nom Nom à retirer
	 */
	public void removeConnectes(String nom) {
		this.modele.removeConnectes(nom);
	}
	
	/**
	 * Ajoute un message à la discussion (en provenance du serveur par l'intermédiare de ConnexionServeur)
	 * @param str Message à ajouter
	 */
	public void addDiscussion(String str) {
		this.modele.addDiscussion(str);
	}
	
	/**
	 * Modifie le flag de l'état de la connexion (en provenance de ConnexionServeur)
	 * @param c Etat de la connexion avec le serveur
	 */
	public void setConnexion(boolean c) {
		this.modele.setConnexion(c);
		this.modele.clearConnectes();
	}
	
	public int getNbConnectes() {
		return this.modele.getNbConnectes();
	}
}
