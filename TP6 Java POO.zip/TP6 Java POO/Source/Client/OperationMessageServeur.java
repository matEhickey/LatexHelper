// Imports
import java.util.ArrayList;

/**
 * Opération réalisé pour ajouter un message à la discussion
 */
public class OperationMessageServeur extends Operation {
	
	// Méthodes de classe
	
	/**
	 * Constructeur
	 * @param message Message sur lequel l'opération doit porter
	 */
	public OperationMessageServeur(Message message) {
		super(message);
	}
	
	// Méthodes d'instances
	
	/**
	 * Ajoute le message dans la discussion
	 */
	public void traiter() {
		// Lecture des arguments
		ArrayList arguments = this.getMessage().getArguments();
		String str = (String) arguments.get(0);
		Controleur c = (Controleur) arguments.get(1);
		
		// Envoi du message au controleur
		c.addDiscussion(str);
	}
}
