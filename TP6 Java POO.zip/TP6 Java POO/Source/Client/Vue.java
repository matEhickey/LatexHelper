// Imports
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedList;
import java.util.Iterator;

/**
 * La classe Vue affiche les données du modèle dans une fenêtre utilisateur
 *
 * @author Kévin Démaret
 * @version 1.0
 */
public class Vue extends JFrame implements Observateur {
	
	// Attributs d'instance
	
	private JPanel p;
	private JLabel lbNom;
	private JTextField chNom;
	private JLabel lbIp;
	private JTextField chIp;
	private JLabel lbPort;
	private JTextField chPort;
	private JLabel lbMessage;
	private JTextArea chMessage;
	private JLabel lbConnectes;
	private JTextArea chConnectes;
	private JScrollPane scrollChConnectes;
	private JLabel lbDiscussion;
	private JTextArea chDiscussion;
	private JScrollPane scrollChDiscussion;
	private JButton btEnvoyer;
	private JButton btCoDeco;
	private Controleur controleur;
	
	// Méthodes de classe
	
	/**
	 * Constructeur
	 * @param c Contrôleur de la vue
	 */
	public Vue(Controleur c) {
		
		// Liaison avec le contrôleur
		this.controleur = c;
	    
	    // Création du panel
	    this.p = new JPanel();
		this.p.setPreferredSize(new Dimension(465, 575));
		this.p.setLayout(null);
	    
	    // Champ nom
	    this.lbNom = new JLabel("Nom");
	    this.p.add(this.lbNom);
	    
	    this.chNom = new JTextField(16);
	    this.p.add(this.chNom);
	    
	    // Champ IP
	    this.lbIp = new JLabel("Ip");
	    this.p.add(this.lbIp);
	    
	    this.chIp = new JTextField(16);
	    this.p.add(this.chIp);
	    
	    // Champ Port
	    this.lbPort = new JLabel("Port");
	    this.p.add(this.lbPort);
	    
	    this.chPort = new JTextField(16);
	    this.p.add(this.chPort);
	    
	    // Bouton connexion/de-connexion
	    this.btCoDeco = new JButton("Connexion/Déconnexion");
	    this.p.add(this.btCoDeco);
	    
	    // Champ message
	    this.lbMessage = new JLabel("Message");
	    this.p.add(this.lbMessage);
	    
	    this.chMessage = new JTextArea(3, 16);
	    this.p.add(this.chMessage);
	    
	    // Bouton envoyer
	    this.btEnvoyer = new JButton("Envoyer");
	    this.p.add(this.btEnvoyer);
	    
	    // Connectés
	    this.lbConnectes = new JLabel("Connectés");
	    this.p.add(this.lbConnectes);
	    
	    this.chConnectes = new JTextArea(3, 16);
		this.chConnectes.setEditable(false);
		this.chConnectes.setLineWrap(true);
		this.chConnectes.setWrapStyleWord(true);
		
		this.scrollChConnectes = new JScrollPane(this.chConnectes);
		this.scrollChConnectes.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		this.p.add(this.scrollChConnectes);
	    
	    // Discussion
	    this.lbDiscussion = new JLabel("Discussion");
	    this.p.add(this.lbDiscussion);
	    
	    this.chDiscussion = new JTextArea(3, 16);
		this.chDiscussion.setEditable(false);
		this.chDiscussion.setLineWrap(true);
		this.chDiscussion.setWrapStyleWord(true);
		
		this.scrollChDiscussion = new JScrollPane(this.chDiscussion);
		this.scrollChDiscussion.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	    this.p.add(this.scrollChDiscussion);
		
		// Positionnement des éléments
		this.btEnvoyer.setBounds(185, 535, 255, 25);
        this.btCoDeco.setBounds(295, 40, 150, 25);
        this.chNom.setBounds(65, 5, 150, 25);
        this.chPort.setBounds(65, 40, 150, 25);
        this.lbNom.setBounds(15, 5, 100, 25);
        this.chIp.setBounds(295, 5, 150, 25);
        this.lbIp.setBounds(265, 5, 100, 25);
        this.lbPort.setBounds(15, 40, 100, 25);
        this.lbConnectes.setBounds(55, 85, 100, 25);
        this.lbMessage.setBounds(285, 360, 100, 25);
        this.scrollChConnectes.setBounds(15, 110, 145, 450);
        this.chMessage.setBounds(185, 385, 255, 125);
        this.scrollChDiscussion.setBounds(185, 110, 255, 240);
        this.lbDiscussion.setBounds(280, 85, 100, 25);
		
		// Liaison avec des listener
		this.btCoDeco.addActionListener(new BtCoDecoListener());
		this.btEnvoyer.addActionListener(new BtEnvoyerListener());
		this.scrollChDiscussion.getVerticalScrollBar().addAdjustmentListener(new BasDiscussion());
		
		// Création de la fenêtre
		this.setTitle("Supper Cat (client)");
		this.setSize(465, 575);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);             
		this.setResizable(false);
		this.setContentPane(this.p);
		this.pack();
		this.setVisible(true);
	}
	
	// Méthodes d'instances
	
	/**
	 * Mes à jour la vue
	 * @param Observable à afficher
	 */
	public void miseAJour(Observable obs) {
		
		// Récupération des données du modèle
		Iterator itr = null;
		String texte = null;
		Modele m = (Modele) obs;
		boolean connexion = m.getConnexion();
		
		// Gestion du bouton de connexion/dé-connexion
		if(connexion)
			btCoDeco.setText("Deconnexion");
		else
			btCoDeco.setText("Connexion");
		
		// Activation/dé-activation des champs
		lbConnectes.setEnabled(connexion);
		chConnectes.setEnabled(connexion);
		lbMessage.setEnabled(connexion);
		chMessage.setEnabled(connexion);
		btEnvoyer.setEnabled(connexion);
		
		connexion = !connexion;
		lbNom.setEnabled(connexion);
		chNom.setEnabled(connexion);
		lbIp.setEnabled(connexion);
		chIp.setEnabled(connexion);
		lbPort.setEnabled(connexion);
		chPort.setEnabled(connexion);
		
		// Liste des connectés
		itr = m.getConnectes();
		texte = "";
		while( itr.hasNext() ) {
			texte += (String) itr.next() + '\n';
		}
		chConnectes.setText(texte);
		
		// Historique des messages
		itr = m.getDiscussion();
		texte = "";
		while( itr.hasNext() ) {
			texte += (String) itr.next() + '\n';
		}
		chDiscussion.setText(texte);
	}
	
	/**
	 * OnClick sur le bouton connexion/deconnexion, envoi les données des champs Nom, Ip et Port
	 */
	class BtCoDecoListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			controleur.gestionConnexion(chNom.getText(), chIp.getText(), Integer.parseInt(chPort.getText()));
		}
	}
	
	/**
	 * OnClick sur le bouton envoyer, envoi les données du champ Message
	 */
	class BtEnvoyerListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			controleur.envoyerMessage(chMessage.getText());
			chMessage.setText("");
		}
	}
	
	/**
	 * Maintient la barre vertical de la discussion toujour en bas
	 */
	class BasDiscussion implements AdjustmentListener {
		public void adjustmentValueChanged(AdjustmentEvent e) {
			e.getAdjustable().setValue(e.getAdjustable().getMaximum());
		}
	}
}
