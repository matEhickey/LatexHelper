// Imports
import java.io.Serializable;
import java.util.ArrayList;
import java.lang.reflect.Constructor;

/**
 * La classe Message fournit des objets sérialisables pour gérer les données échangées entre les clients et le serveur
 */
public class Message implements Serializable {
	
	// Attributs d'instances
	
	private String operation;
	private ArrayList<Object> arguments;
	
	// Méthodes de classe
	
	/**
	 * Constructeur
	 * @param operation Nom de la classe chargé de traiter le message chez l'interlocuteur
	 */
	public Message(String operation) {
		this.operation = operation;
		this.arguments = new ArrayList<Object>();
	}
	
	/**
	 * Traite un message
	 * @param msg Message à traiter
	 */
	public static void traiter(Message msg) {
		try {
			// Création d'une instance adapté au traitement du message
			Class<?> cla = Class.forName( msg.getOperation() );
			Constructor cst = cla.getConstructor(Message.class);
			Operation ope = (Operation) cst.newInstance( msg );
			// Traitement du message
			ope.traiter();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// Méthodes d'instances
	
	/**
	 * Ajoute un argument au message
	 * @param obj Argument à ajouter
	 */
	public void ajouterArgument(Object obj) {
		this.arguments.add(obj);
	}
	
	/**
	 * Renvoi le nom de la classe chargé de traiter le message
	 */
	public String getOperation() {
		return this.operation;
	}
	
	/**
	 * Renvoi la liste des arguments du message
	 */
	public ArrayList getArguments() {
		return this.arguments;
	}
	
}
