/**
 * La classe Main instantie les objets du modèle MVC et les lies entre eux
 *
 * @author Kévin Démaret
 * @version 1.0
 */
public class Main {
	
	public static void main (String[] args) {
		Modele m = new Modele();
		Controleur c = new Controleur(m);
		Vue v = new Vue(c);
		m.attacherObservateur(v);
	}
	
}
