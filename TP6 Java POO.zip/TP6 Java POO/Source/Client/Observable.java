/**
 * L'interface Observable permet de définir des classes comme observables par des classes observatrices
 *
 * @author Kévin Démaret
 * @version 1.0
 */
public interface Observable {
	
	public void attacherObservateur(Observateur obs);
	public void detacherObservateur(Observateur obs);
	public void notifierObservateurs();
	
}
