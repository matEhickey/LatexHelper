// Imports
import java.util.LinkedList;
import java.util.Iterator;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 * La classe Modèle contient toutes les données de l'application
 *
 * @author Kévin Démaret
 * @version 1.0
 */
public class Modele implements Observable {
	
	// Attributs d'instance
	
	// private String nom;
	// private String ip;
	// private int port;
	private LinkedList<String> discussion;
	private LinkedList<String> connectes;
	// private String message;
	private boolean connexion;
	private LinkedList<Observateur> observateurs;
	
	// Méthodes de classe
	
	/**
	 * Constructeur
	 */
	public Modele() {
		// this.nom = null;
		// this.ip = null;
		// this.port = 0;
		this.discussion = new LinkedList<String>();
		this.connectes = new LinkedList<String>();
		// this.message = null;
		this.connexion = false;
		this.observateurs = new LinkedList<Observateur>();
	}
	
	// Méthodes d'instances
	
	// public void setNom(String nom) {
		// this.nom = nom;
		// this.notifierObservateurs();
	// }
	
	// public String getNom() {
		// return this.nom;
	// }
	
	// public void setIp(String ip) {
		// this.ip = ip;
		// this.notifierObservateurs();
	// }
	
	// public String getIp() {
		// return this.ip;
	// }
	
	// public void setPort(int port) {
		// this.port = port;
		// this.notifierObservateurs();
	// }
	
	// public int getPort() {
		// return this.port;
	// }
	
	/**
	 * Ajoute du texte à la discussion
	 */
	public void addDiscussion(String str) {
		
		if( this.discussion.size() == 100 )
			this.discussion.removeFirst();
		
		Date d = new Date();
		SimpleDateFormat df = new SimpleDateFormat("H:m");
		this.discussion.addLast("(" + df.format(d) + ") " + str);
		
		this.notifierObservateurs();
	}
	
	/**
	 * Vide la discussion
	 */
	public void clearDiscussion() {
		this.discussion.clear();
		this.notifierObservateurs();
	}
	
	/**
	 * Renvoi un itérateur sur la discussion
	 */
	public Iterator getDiscussion() {
		return this.discussion.iterator();
	}
	
	/**
	 * Ajoute un nom à la liste des connectés
	 */
	public void addConnectes(String nom) {
		this.connectes.add(nom);
		this.notifierObservateurs();
	}
	
	/**
	 * Vide la liste des connectés
	 */
	public void clearConnectes() {
		this.connectes.clear();
		this.notifierObservateurs();
	}
	
	/**
	 * Supprime un nom de la liste des connectés
	 */
	public void removeConnectes(String n) {
		int size = this.connectes.size();
		String nom = null;
		int i = 0;
		for( i=0 ; i<size ; i++ ) {
			nom = this.connectes.get(i);
			
			if( nom.equals(n) ) {
				this.connectes.remove(i);
				this.notifierObservateurs();
				return;
			}
		}
	}
	
	/**
	 * Renvoi un itérateur sur la liste des connectés
	 */
	public Iterator getConnectes() {
		return this.connectes.iterator();
	}
	
	/**
	 * Renvoi le nombre de connectés au serveur
	 */
	public int getNbConnectes() {
		return this.connectes.size();
	}
	
	public boolean getConnexion() {
		return this.connexion;
	}
	
	public void setConnexion(boolean connexion) {
		this.connexion = connexion;
		this.notifierObservateurs();
	}
	
	// public void setMessage(String nom) {
		// this.message = nom;
		// this.notifierObservateurs();
	// }
	
	// public String getMessage() {
		// return this.message;
	// }
	
	// DP observateur
	
	/**
	 * Attache un observateur à l'instance
	 * @param obs Observateur à ajouter
	 */
	public void attacherObservateur(Observateur obs) {
		this.observateurs.add(obs);
		obs.miseAJour(this);
	}
	
	/**
	 * Détache un onservateur de l'instance
	 * @param obs Observateur à détacher
	 */
	public void detacherObservateur(Observateur obs) {
		this.observateurs.remove(obs);
	}
	
	/**
	 * Notifie tout tous les observateurs de l'instance qu'il y a une mise à jour
	 */
	public void notifierObservateurs() {
		for(Observateur obs : this.observateurs) {
			obs.miseAJour(this);
		}
	}
	
}
