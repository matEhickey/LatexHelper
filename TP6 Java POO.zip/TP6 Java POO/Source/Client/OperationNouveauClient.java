// Imports
import java.util.ArrayList;

/**
 * Opération réalisé pour ajouter un/des utilisateur(s) à la liste des connectés
 */
public class OperationNouveauClient extends Operation {
	
	// Méthodes de classe
	
	/**
	 * Constructeur
	 * @param message Message sur lequel l'opération doit porter
	 */
	public OperationNouveauClient(Message message) {
		super(message);
	}
	
	// Méthodes d'instances
	
	/**
	 * Ajoute le(s) nom à la liste des connectées
	 */
	public void traiter() {
		
		// Lecture des arguments
		ArrayList arguments = this.getMessage().getArguments();
		int size = arguments.size();
		Controleur c = (Controleur) arguments.get(size-1);
		String nom;
		
		boolean flag = c.getNbConnectes() != 0; // False si ce n'est pas la première requête du genre reçu
		
		// Envoi le(s) nom(s) au controleur
		for( int i=0 ; i<size-1 ; i++ ) {
			nom = (String) arguments.get(i);
			c.addConnectes( nom );
			
			if(flag)
				c.addDiscussion( nom + " s'est connecté(e)." );
		}
	}
}
