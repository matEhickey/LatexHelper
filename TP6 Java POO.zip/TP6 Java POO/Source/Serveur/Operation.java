/**
 *
 */
public abstract class Operation {
	
	// Attributs d'instances
	
	private Message message;
	
	// Méthodes de classe
	
	/**
	 * Constructeur
	 * @param message Message sur lequel l'opération doit porter
	 */
	public Operation(Message message) {
		this.message = message;
	}
	
	// Méthodes d'instances
	
	/**
	 * Renvoi le message
	 */
	public Message getMessage() {
		return this.message;
	}
	
	/**
	 * Traite le message, à implémenter dans les classes filles
	 */
	public abstract void traiter();
	
}
