// Imports
import java.io.*;
import java.net.*;

/**
 * Gére les traitements liées à un client
 */
public class Client implements Runnable {
	
	// Attributs de classe
	
	private static int nbClients = 0;
	
	// Attributs d'instances
	
	private int id;
	private Serveur serveur;
	private Socket socket;
	private String nom;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	private Thread thread;
	
	// Méthodes de classe
	
	/**
	 * @param sc serveur dont dépend le client
	 * @param s Socket du client
	 */
	public Client(Serveur sc, Socket s) {
		
		this.id = nbClients++;
		this.serveur = sc;
		this.socket = s;
		
		// Log
		this.serveur.ajouterDebug( "Nouvelle connexion de " + this.getIp() );
		
		// Liaison des entrées/sorties
		try {
			this.out = new ObjectOutputStream(this.socket.getOutputStream());
			this.out.flush();
			this.in = new ObjectInputStream(this.socket.getInputStream());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		// Ajout du client à la liste
		this.serveur.ajouterClient(this);
		
		// Pas de nom pour l'instant
		this.nom = "";
		
		// Lancement d'un thread
		this.thread = new Thread(this);
		this.thread.start();
	}
	
	/**
	 * Coupe la connexion avec le serveur
	 */
	public void arreter() {
		
		// Arrêt du tread
		if(this.thread != null)
			this.thread.interrupt();
		
		// Fermeture du socket
		try {
			if(this.socket != null)
				this.socket.close();
		}
		catch(Exception e) {
			// e.printStackTrace();
		}
		
		// Mise à null des références
		this.serveur = null;
		this.thread = null;
	}
	
	// Méthodes d'instances
	
	/**
	 * Ecoute de données entrantes sur le client
	 */
	public void run() {
		
		Message msg = null;
		
		try {
			while(true) {
				msg = (Message) this.in.readObject(); // On dé-sérialise le message
				this.serveur.ajouterDebug( "Réception d'un message du type " + msg.getOperation() + " depuis " + this + ", " + msg.getArguments().size() + " argument(s)" ); // Log
				msg.ajouterArgument(this); // On ajoute une référence du client pour le traitement
				Message.traiter(msg); // Traitement du message
			}
		}
		catch(Exception e) {
			// e.printStackTrace(); // Debug
			
			// Log
			this.serveur.ajouterDebug( "Fin connexion de " + this.getIp() );
			
			// Diffusion du nom à supprimer à tous les clients sauf le concerné
			msg = new Message("OperationSupprimerClient");
			msg.ajouterArgument(this.nom);
			this.serveur.diffuserMessage(msg, this);
			
			// Discussion
			this.serveur.ajouterDiscussion(this.nom + " s'est dé-connecté(e).");
			
			// Suppression du client de la liste
			this.serveur.supprimerClient(this);
			
			// Arrêt du thread
			// this.thread.interrupt(); // Thread.currentThread().interrupt();
			this.arreter();
		}
	}
	
	/**
	 * Envoi de données au client
	 * @param msg Message à transmettre au client
	 */
	public void envoyerMessage(Message msg) {
		try {
			this.out.writeObject(msg);
			this.out.flush();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @return Renvoi l'id de l'instance client
	 */
	public int getId() {
		return this.id;
	}
	
	/**
	 * @return Renvoi le nom du client
	 */
	public String getNom() {
		return this.nom;
	}
	
	/**
	 * Modifie le nom du client
	 * @nom Nouvelle valeur pour le nom du client
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	/**
	 * @return Renvoi le serveur auquel est attaché le client
	 */
	public Serveur getServeur() {
		return this.serveur;
	}
	
	/**
	 * @return Renvoi le socket du client
	 */
	public Socket getSocket() {
		return this.socket;
	}
	
	/**
	 * @return Renvoi l'adresse Ip du client
	 */
	public String getIp() {
		// return this.socket.getRemoteSocketAddress().toString();
		return this.socket.getInetAddress().getHostAddress();
	}
	
	/**
	 * @return Renvoi une chaîne de carractères représentant l'instance
	 */
	public String toString() {
		return "<Client:" + this.id + ">";
	}
}
