// Imports
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Iterator;

/**
 * La classe Fenetre affiche les données du modèle dans une fenêtre utilisateur
 *
 * @author Kévin Démaret
 * @version 1.0
 */
public class Fenetre extends JFrame implements Observateur {
	
	// Attributs d'instances
	
	private Controleur controleur;
	private JPanel p;
	private JLabel lbPort;
	private JTextField chPort;
	private JButton btDemarrer;
	private JLabel lbDebug;
	private JTextArea chDebug;
	private JScrollPane scrollChDebug;
	private JLabel lbDiscussion;
	private JTextArea chDiscussion;
	private JScrollPane scrollChDiscussion;
	private JLabel lbConnectes;
	private JTextArea chConnectes;
	
	// Méthodes de classe
	
	/**
	 * Constructeur
	 */
	public Fenetre(Controleur controleur) {
		
		// Liaison du controleur
		this.controleur = controleur;
		
		// Création du panel
	    this.p = new JPanel();
		this.p.setPreferredSize(new Dimension(847, 561));
		this.p.setLayout(null);
		
		// Création des éléments
		this.lbPort = new JLabel("Port");
		this.chPort = new JTextField(5);
		
		this.btDemarrer = new JButton("Démarrer/Arrêter");
		
		this.lbDebug = new JLabel("Debug");
		this.chDebug = new JTextArea(5, 5);
		this.chDebug.setEditable(false);
		this.chDebug.setLineWrap(true);
		this.chDebug.setWrapStyleWord(true);
		
		this.scrollChDebug = new JScrollPane(this.chDebug);
		this.scrollChDebug.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		// this.p.add(this.scrollChDebug);
		
		this.lbDiscussion = new JLabel("Discussion");
		this.chDiscussion = new JTextArea(5, 5);
		this.chDiscussion.setEditable(false);
		this.chDiscussion.setLineWrap(true);
		this.chDiscussion.setWrapStyleWord(true);
		
		this.scrollChDiscussion = new JScrollPane(this.chDiscussion);
		this.scrollChDiscussion.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	    // this.p.add(this.scrollChDiscussion);
		
		this.lbConnectes = new JLabel("Connectés");
		this.chConnectes = new JTextArea(5, 5);
		this.chConnectes.setEditable(false);
		this.chConnectes.setLineWrap(true);
		this.chConnectes.setWrapStyleWord(true);
		
		// Ajout des éléments au panel
		this.p.add(lbPort);
		this.p.add(chPort);
		this.p.add(btDemarrer);
		this.p.add(lbDebug);
		this.p.add(scrollChDebug);
		this.p.add(lbDiscussion);
		this.p.add(scrollChDiscussion);
		this.p.add(lbConnectes);
		this.p.add(chConnectes);
		
		// Placement des éléments
		this.lbPort.setBounds(10, 15, 100, 25);
		this.chPort.setBounds(45, 15, 50, 25);
		this.btDemarrer.setBounds(110, 15, 140, 25);
		this.lbDebug.setBounds(285, 55, 100, 25);
		this.scrollChDebug.setBounds(10, 80, 610, 200);
		this.lbDiscussion.setBounds(285, 285, 100, 25);
		this.scrollChDiscussion.setBounds(10, 310, 610, 245);
		this.lbConnectes.setBounds(705, 55, 100, 25);
		this.chConnectes.setBounds(635, 80, 205, 475);
		
		// Liaison avec des listener
		this.btDemarrer.addActionListener(new BtDeArListener());
		this.scrollChDebug.getVerticalScrollBar().addAdjustmentListener(new BareEnBas());
		this.scrollChDiscussion.getVerticalScrollBar().addAdjustmentListener(new BareEnBas());
		
		// Création de la fenêtre
		this.setTitle("Supper Cat (serveur)");
		this.setSize(847, 561);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);             
		this.setResizable(false);
		this.setContentPane(this.p);
		this.pack();
		this.setVisible(true);
	}
	
	// Méthodes d'instances
	
	/**
	 * OnClick sur le bouton connexion/deconnexion, envoi les données des champs Nom, Ip et Port
	 */
	class BtDeArListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			controleur.gestionConnexion(Integer.parseInt(chPort.getText()));
		}
	}
	
	/**
	 * Maintient la barre vertical toujour en bas
	 */
	class BareEnBas implements AdjustmentListener {
		public void adjustmentValueChanged(AdjustmentEvent e) {
			e.getAdjustable().setValue(e.getAdjustable().getMaximum());
		}
	}
	
	/**
	 * Mes à jour la vue
	 * @param Observable à afficher
	 */
	public void miseAJour(Observable observable) {
		
		// Lecture des arguments
		Serveur serveur = (Serveur) observable;
		boolean etat = serveur.getConnexion();
		
		// Gestion du bouton démarrer/arrêter
		if(etat)
			btDemarrer.setText("Arrêter");
		else
			btDemarrer.setText("Démarrer");
		
		// Activation/dé-activation des champs
		lbConnectes.setEnabled(etat);
		chConnectes.setEnabled(etat);
		etat = !etat;
		lbPort.setEnabled(etat);
		chPort.setEnabled(etat);
		
		// Debug
		this.afficherDebug( serveur.getDebug() );
		
		// Discussion
		this.afficherDiscussion( serveur.getDiscussion() );
		
		// Liste des connectés
		this.afficherConnectes( serveur.getClients() );
	}
	
	/**
	 * Met à jour la liste des connectés
	 */
	private void afficherConnectes(Iterator itr) {
		String texte = "";
		Client client;
		
		while( itr.hasNext() ) {
			client = (Client) itr.next();
			texte += client.getId() + " : " + client.getIp() + " : " + client.getNom() + '\n';
		}
		
		chConnectes.setText(texte);
	}
	
	/**
	 * Met à jour le debug
	 */
	private void afficherDebug(Iterator itr) {
		String texte = "";
		
		while( itr.hasNext() ) {
			texte += (String) itr.next() + '\n';
		}
		
		chDebug.setText(texte);
	}
	
	/**
	 * Met à jour la discussion
	 */
	private void afficherDiscussion(Iterator itr) {
		String texte = "";
		
		while( itr.hasNext() ) {
			texte += (String) itr.next() + '\n';
		}
		
		chDiscussion.setText(texte);
	}
}
