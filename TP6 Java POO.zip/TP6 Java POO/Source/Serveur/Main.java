/**
 * La classe Main instantie les objets du modèle MVC et les lies entre eux
 *
 * @author Kévin Démaret
 * @version 1.0
 */
public class Main {
	
	public static void main (String[] args) {
		Serveur s = new Serveur(); // Modèle
		Controleur c = new Controleur(s); // Controleur
		Fenetre f = new Fenetre(c); // Vue
		s.attacherObservateur(f);
	}
	
}
