// Imports
import java.util.ArrayList;

/**
 * Opération réalisé lors de la connexion d'un client
 */
public class OperationMessageClient extends Operation {
	
	// Méthodes de classe
	
	/**
	 * Constructeur
	 * @param message Message sur lequel l'opération doit porter
	 */
	public OperationMessageClient(Message message) {
		super(message);
	}
	
	// Méthodes d'instances
	
	/**
	 * Met à jour le pseudo du client et diffuse ce dernier à tous les clients
	 */
	public void traiter() {
		// Lecture des arguments
		ArrayList arguments = this.getMessage().getArguments();
		String str = (String) arguments.get(0);
		Client c = (Client) arguments.get(1);
		
		// Diffusion du message aux clients
		Message msg = new Message("OperationMessageServeur");
		msg.ajouterArgument(c.getNom() + " : " + str);
		c.getServeur().diffuserMessage(msg);
		
		// Log
		c.getServeur().ajouterDiscussion(c.getNom() + " : " + str);
	}
}
