/**
 * La classe controleur orchestre la classe Fenetre et Serveur
 */
public class Controleur {
	
	// Attributs d'instance
	
	private Serveur serveur;
	
	// Méthodes de classe
	
	/**
	 * Constructeur
	 */
	public Controleur(Serveur serveur) {
		this.serveur = serveur;
	}
	
	/**
	 * @param Port sur lequel lancer le serveur
	 */
	public void gestionConnexion(int port) {
		if( this.serveur.getConnexion() ) // Si le serveur est en fonctionnement
			this.serveur.arreter(); // On l'arrête
		else // Sinon il n'est pas en fonctionnement
			this.serveur.demarrer(port); // On le lance sur le port spécifié
	}
}
