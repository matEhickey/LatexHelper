// Imports
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Opération réalisé lors de la connexion d'un client
 */
public class OperationBonjour extends Operation {
	
	// Méthodes de classe
	
	/**
	 * Constructeur
	 * @param message Message sur lequel l'opération doit porter
	 */
	public OperationBonjour(Message message) {
		super(message);
	}
	
	// Méthodes d'instances
	
	/**
	 * Met à jour le pseudo du client et diffuse ce dernier à tous les clients
	 */
	public void traiter() {
		
		// Lecture des arguments
		ArrayList arguments = this.getMessage().getArguments();
		String n = (String) arguments.get(0);
		Client c = (Client) arguments.get(1);
		Serveur s = c.getServeur();
		
		Iterator itr;
		Message msg;
		
		// Si le nom est déjà utilisé par un autre client
		itr = s.getClients();
		while( itr.hasNext() ) {
			if( ((Client) itr.next()).getNom().equals(n) ) {
				s.ajouterDebug( "Conflit de nom pour " + c );
				msg = new Message( "OperationMessageServeur" );
				msg.ajouterArgument( "Le nom que vous avez choisi est déjà utilisé. Veillez en choisir un autre puis reconnectez vous." );
				c.envoyerMessage(msg);
				c.arreter();
				s.supprimerClient(c);
				return;
			}
		}
		
		// Maj du nom
		c.setNom(n);
		
		// Diffusion du nouveau nom à tous les clients sauf le concerné
		msg = new Message("OperationNouveauClient");
		msg.ajouterArgument(n);
		s.diffuserMessage(msg, c);
		
		// Envoi de tous les noms au client concerné
		itr = s.getClients();
		msg = new Message("OperationNouveauClient");
		while( itr.hasNext() ) {
			msg.ajouterArgument( ((Client) itr.next()).getNom() );
		}
		c.envoyerMessage(msg);
		
		// Log
		s.ajouterDiscussion(c.getNom() + " s'est connecté(e).");
	}
}
