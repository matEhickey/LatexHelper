// Imports
import java.io.*;
import java.net.*;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 * La classe ServeurCat gère les connexion entrantes et une liste de connexion clients
 *
 * @author Kévin Démaret
 * @version 1.0
 */
public class Serveur implements Observable, Runnable {
	
	// Attributs d'instances
	
	private LinkedList<Client> clients;
	private ServerSocket serveurSocket;
	private Thread thread;
	private LinkedList<String> debug;
	private LinkedList<String> discussion;
	private LinkedList<Observateur> observateurs;
	
	
	// Méthodes de classe
	
	/**
	 * Cnnstructeur
	 */
	public Serveur() {
		this.clients = new LinkedList<Client>();
		this.serveurSocket = null;
		this.thread = null;
		this.debug = new LinkedList<String>();
		this.discussion = new LinkedList<String>();
		this.observateurs = new LinkedList<Observateur>();
	}
	
	// Méthodes d'instances
	
	/**
	 * Lance un socket d'écoute sur le port spécifié
	 */
	public void demarrer(int port) {
		try {
			// Initialisation du socket
			this.serveurSocket = new ServerSocket(port);
			// serveurSocket.setSoTimeout(1000);
			
			// Log
			this.ajouterDebug( "Serveur lancé sur le port : " + this.getPort() );
			
			// Discussion
			this.ajouterDiscussion( "--- Démarrage serveur ---" );
			
			// Lancement du thread
			this.thread = new Thread(this);
			this.thread.start();
		}
		catch (Exception e) {
			// e.printStackTrace();
			this.arreter();
		}
		
		this.notifierObservateurs();
	}
	
	/**
	 * Arrête le serveur
	 */
	public void arreter() {
		
		// Arrêt du tread
		if(this.thread != null)
			this.thread.interrupt();
		
		// Fermeture du socket serveur
		try {
			if(this.serveurSocket != null)
				this.serveurSocket.close();
		}
		catch(Exception e) {
			// e.printStackTrace();
		}
		
		// Fermeture des sockets des clients
		for(Client client : this.clients) {
			client.arreter();
		}
		
		// Nettoyage de la liste
		this.clients.clear();
		
		// Mise à null des références
		this.serveurSocket = null;
		this.thread = null;
		
		// Log
		this.ajouterDebug( "Serveur arrêté" );
		
		// Discussion
		this.ajouterDiscussion( "--- Arrêt serveur ---" );
		
		this.notifierObservateurs();
	}
	
	/**
	 * Gestion des connexion entrantes
	 */
	public void run() {
		try {
			while(true) {
				// On instantie un objet client à chaque nouvelle connexion, se dernier viendra s'enregister dans la liste des clients par lui même
				new Client(this, this.serveurSocket.accept());
			}
		}
		catch(Exception e) {
			// e.printStackTrace();
		}
	}
	
	/**
	 * Ajoute un client à la liste des connectées
	 * @param c Client à ajouter à la liste
	 */
	public void ajouterClient(Client c) {
		this.clients.add(c);
		
		// Log
		this.ajouterDebug( "Connexion ajouté à la liste " + c );
		
		this.notifierObservateurs();
	}
	
	/**
	 * Supprime un client de la liste des connectées
	 * @param c Client à retirer de la liste
	 */
	public void supprimerClient(Client c) {
		this.clients.remove(c);
		
		// Log
		this.ajouterDebug( "Connexion supprimé de la liste " + c );
		
		this.notifierObservateurs();
	}
	
	/**
	 * Renvoi un itérateur sur la liste des clients
	 */
	public Iterator getClients() {
		return this.clients.iterator();
	}
	
	/**
	 * Renvoi le nombre de client connectées au serveur
	 */
	public int getNbCLient() {
		return this.clients.size();
	}
	
	/**
	 * Envoi un message à tous les clients connectées au serveur
	 * @param msg Message à diffuser
	 */
	public void diffuserMessage(Message msg) {
		diffuserMessage(msg, null);
	}
	
	/**
	 * Envoi un message à tous les clients connectées au serveur sauf un
	 * @param msg Message à diffuser
	 * @param c Cient exclu de la diffusion
	 */
	public void diffuserMessage(Message msg, Client c) {
		for(Client client : this.clients) {
			if( (client.getNom() != null) && (client != c) )
				client.envoyerMessage(msg);
		}
		this.ajouterDebug("Diffusion d'un message.");
	}
	
	/**
	 * @return Renvoi le port sur lequel le serveur a été lancé
	 */
	public int getPort() {
		return this.serveurSocket.getLocalPort();
	}
	
	/**
	 * @return Renvoi l'état du serveur, true si le port est ouvert, false si non
	 */
	public boolean getConnexion() {
		return (this.serveurSocket != null);
	}
	
	/**
	 * Ajoute un log au debug
	 * @param str Message à ajouter
	 */
	public void ajouterDebug(String str) {
		
		if( this.debug.size() > 128 )
			this.debug.removeFirst();
		
		Date d = new Date();
		SimpleDateFormat df = new SimpleDateFormat("H:m");
		this.debug.addLast("(" + df.format(d) + ") " + str);
		
		// System.out.println( "(" + df.format(d) + ") " + str );
		
		this.notifierObservateurs();
	}
	
	/**
	 * @return Renvoi un itérateur sur les logs du debug
	 */
	public Iterator getDebug() {
		return this.debug.iterator();
	}
	
	/**
	 * Ajoute un message à la discussion
	 * @param str Message à ajouter
	 */
	public void ajouterDiscussion(String str) {
		
		if( this.discussion.size() > 128 )
			this.discussion.removeFirst();
		
		Date d = new Date();
		SimpleDateFormat df = new SimpleDateFormat("H:m");
		this.discussion.addLast("(" + df.format(d) + ") " + str);
		
		this.notifierObservateurs();
	}
	
	/**
	 * @return Renvoi un itérateur sur les messages de la discussion
	 */
	public Iterator getDiscussion() {
		return this.discussion.iterator();
	}
	
	// DP observateur
	
	/**
	 * Attache un observateur à l'instance
	 * @param observateur Observateur à ajouter
	 */
	public void attacherObservateur(Observateur observateur) {
		this.observateurs.add(observateur);
		observateur.miseAJour(this);
	}
	
	/**
	 * Détache un observateur de l'instance
	 * @param observateur Observateur à détacher
	 */
	public void detacherObservateur(Observateur observateur) {
		this.observateurs.remove(observateur);
	}
	
	/**
	 * Notifie tout tous les observateurs de l'instance qu'il y a une mise à jour
	 */
	public void notifierObservateurs() {
		for(Observateur observateur : this.observateurs) {
			observateur.miseAJour(this);
		}
	}
}
