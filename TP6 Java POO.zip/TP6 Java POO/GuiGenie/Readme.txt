GuiGenie 1.0.0 - Readme file.




Requirements:

You must have a Java Virtual Machine version 1.4.0 and above to run this program.
You can get a JVM for free from http://java.sun.com



How to run GuiGenie:

Double click on GuiGenie.exe (Windows) or GuiGenie.jar (any other OS) to run it.
If this didn't work you can try the following at the command line:
java -jar GuiGenie.jar
